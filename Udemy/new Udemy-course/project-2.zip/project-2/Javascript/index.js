
function thanks(){
   console.log('thanks')
}
thanks();